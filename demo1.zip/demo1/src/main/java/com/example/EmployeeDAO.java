package com.example;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
public class EmployeeDAO {
	

private SessionFactory sessionFactory;
HibernateTemplate hibernateTemplate;  

public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {  
    this.hibernateTemplate = hibernateTemplate;  
}

public void saveEmployee(Employee s){
	
	hibernateTemplate.saveOrUpdate(s);
	
}


}
