package com.example;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class Test {
	public static void main(String[] args) {
		ApplicationContext ctx =new ClassPathXmlApplicationContext("applicationContext.xml");
	

		EmployeeDAO d=(EmployeeDAO)ctx.getBean("empDao");
		
	
		
		Employee e=new Employee();
		e.setId(10);
		e.setSalary(25000);
		e.setName("ABCD");
		d.saveEmployee(e);
	}

}
